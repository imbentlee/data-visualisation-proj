report
|   | - candlestick-chart-system-test.png
|   | - documentation-of-work.pdf
|   | - gantt-chart.png
|   | - main-class-diagram.png
|   | - rough-sketch-jpg
|   | - unit-test-png
|   | - README.txt
