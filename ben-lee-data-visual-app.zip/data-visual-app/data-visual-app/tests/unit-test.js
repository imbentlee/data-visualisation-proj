const chai = window.chai;
const expect = chai.expect;
console.log("WARNING: This test utilises cdn hence it may not function on your device");
console.log("WARNING: If error message 'Error: global leak detected' shows up, webpage may need to be refeshed multiple times, function is definitely functioning as intended");

describe('splitArray(arr, size)', () => {
  it('This function converts an array into a nested array of a specified size', () => {
      var testArr = [1,2,3,4];
      expect(splitArray(testArr, 2)).to.deep.equal([[1,2], [3,4]])
  })
});

describe('startDates(arr)', () => {
  it('This function returns an array of elements that are made up of the first value of each element in a nested array', () => {
      var testArr = [[1,2], [3,4],[5,6]];
      expect(startDates(testArr)).to.deep.equal([1,3,5])
  })
});

describe('endDates(arr)', () => {
  it('This function returns an array of elements that are made up of the last value of each element in a nested array', () => {
      var testArr = [[1,2], [3,4],[5,6]];
      expect(endDates(testArr)).to.deep.equal([2,4,6])
  })
});

describe('dateRange(start, end)', () => {
  it('This function combines 2 arrays', () => {
      var first = [1,2,3,4,5];
      var second = [9,8,7,6,5];
      expect(dateRange(first, second)).to.deep.equal([1 +'-'+ 9, 2 +'-'+ 8, 3 +'-'+ 7, 4 +'-'+ 6, 5 +'-'+ 5])
  })
});