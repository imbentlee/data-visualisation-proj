function candleStickChart() {

    // Name for the visualisation to appear in the menu bar.
    this.name = "Meta Price Chart";

    this.id = "meta-price-chart";

    this.title = "Meta Price Chart";

    // Property to represent whether data has been loaded.
    this.loaded = false;

    // Preload the data. This function is called automatically by the gallery when a visualisation is added.
    this.preload = function () {
        var self = this;
        this.data = loadTable("./data/meta-stock-price/meta-historical-data-edited.csv", "csv", "header",
            // Callback function to set the value
            // this.loaded to true.
            function (table) {
                self.loaded = true;
            });

    };

    this.setup = function () {
        //creates a div element to house the candlestick visual
        var div = document.createElement('echartDomdiv');
        div.innerHTML += `<div class='chartdom' id="chartdom" style="width: 1024px;height: 576px;z-index: 100;position: relative;left: -1000px;top: 10px"></div>`;
        var container = document.getElementById('app');
        container.appendChild(div);
        
        document.getElementById('chartdom').style.display = ''
        textSize(16);
        textAlign('center', 'center');
        
        this.data_setup();
        
    };
    
    this.data_setup = function () {
        
        //--------------------------------------------
        var date = this.data.getColumn('Date');
        var open = this.data.getColumn('Open');
        var close = this.data.getColumn('Close');
        var low = this.data.getColumn('Low');
        var high = this.data.getColumn('High');
        var change = this.data.getColumn('Change');
        
        //values below are counted based on number of weekdays within time period
        //5 weekdays per wweek, 20 weekdays per month, 260 weekdays per year
        //create arrays for various time periods
        var weeklyDates = splitArray(date, 5);
        var monthlyDates = splitArray(date, 20);
        var yearlyDates = splitArray(date, 260);
        
        //create arrays for various open values
        var weeklyOpen = splitArray(open, 5);
        var monthlyOpen = splitArray(open, 20);
        var yearlyOpen = splitArray(open, 260);
        
        //create arrays for various close values
        var weeklyClose = splitArray(close, 5);
        var monthlyClose = splitArray(close, 20);
        var yearlyClose = splitArray(close, 260);
        
        //create arrays for various low values
        var weeklyLows = splitArray(low, 5);
        var monthlyLows = splitArray(low, 20);
        var yearlyLows = splitArray(low, 260);

        //create arrays for various high values
        var weeklyHighs = splitArray(high, 5);
        var monthlyHighs = splitArray(high, 20);
        var yearlyHighs = splitArray(high, 260);
        
        //create arrays for various %change
        var weeklyChange = splitArray(change, 5);
        var monthlyChange = splitArray(change, 20);
        var yearlyChange = splitArray(change, 260);
        //--------------------------------------------
        
        //identify low of each time period
        var weeklyLow = findLow(weeklyLows);
        var monthlyLow = findLow(monthlyLows);
        var yearlyLow = findLow(yearlyLows);
        
        //identify high of each time period
        var weeklyHigh = findHigh(weeklyHighs);
        var monthlyHigh = findHigh(monthlyHighs);
        var yearlyHigh = findHigh(yearlyHighs);
        
        //identify date range for each time period
        //weekly
        var weeklyStartDate = startDates(weeklyDates);
        var weeklyEndDate = endDates(weeklyDates);
        var weeklyDateRange = dateRange(weeklyStartDate, weeklyEndDate);
        //monthly
        var monthlyStartDate = startDates(monthlyDates);
        var monthlyEndDate = endDates(monthlyDates);
        var monthlyDateRange = dateRange(monthlyStartDate, monthlyEndDate);
        //yearly
        var yearlyStartDate = startDates(yearlyDates);
        var yearlyEndDate = endDates(yearlyDates);
        var yearlyDateRange = dateRange(yearlyStartDate, yearlyEndDate);
        
        //daily values
        var dailyTemp = [];
        date.forEach((ite, i) => {
            var temp = [];
            temp.push(open[i], close[i], low[i], high[i]);
            dailyTemp.push(temp);
        });
        
        //weekly values
        var weeklyTemp = [];
        weeklyDateRange.forEach((ite, i) => {
            var temp = [];
            temp.push(weeklyOpen[i][0], weeklyClose[i][weeklyClose[i].length-1], weeklyLow[i], weeklyHigh[i]);
            weeklyTemp.push(temp);
        });
        
        //monthly values
        var monthlyTemp = [];
        monthlyDateRange.forEach((ite, i) => {
            var temp = [];
            temp.push(monthlyOpen[i][0], monthlyClose[i][monthlyClose[i].length-1], monthlyLow[i], monthlyHigh[i]);
            monthlyTemp.push(temp);
        });
        
        //yearly values
        var yearlyTemp = [];
        yearlyDateRange.forEach((ite, i) => {
            var temp = [];
            temp.push(yearlyOpen[i][0], yearlyClose[i][yearlyClose[i].length-1], yearlyLow[i], yearlyHigh[i]);
            yearlyTemp.push(temp);
        });
        
        //creates the daily chart upon selecting the meta price chart
        createCandlesticks(date, dailyTemp);
        
        //creates buttons to navigate between various time periods and to use drawing tool
        buttons = ['Daily','Weekly','Monthly','Yearly','Draw', 'Stop Draw', 'Clear'];
        for(var i=0; i<buttons.length; i++){
            b = createButton(buttons[i], buttons[i]);
            b.id(buttons[i]);
            b.parent('buttonDiv');
            b.mousePressed( function(){
                //button to display daily chart
                document.getElementById("Daily").onclick = function () {
                    console.log("Daily");
                    createCandlesticks(date, dailyTemp);
                    lineDrawTool(false);
                    clear();
                };
                //button to display weekly chart
                document.getElementById("Weekly").onclick = function () {
                    console.log("Weekly");
                    createCandlesticks(weeklyDateRange, weeklyTemp);
                    lineDrawTool(false);
                    clear();
                };
                //button to display monthly chart
                document.getElementById("Monthly").onclick = function () {
                    console.log("Monthly");
                    createCandlesticks(monthlyDateRange, monthlyTemp);
                    lineDrawTool(false);
                    clear();
                };
                //button to display yearly chart
                document.getElementById("Yearly").onclick = function () {
                    console.log("Yearly");
                    createCandlesticks(yearlyDateRange, yearlyTemp);
                    lineDrawTool(false);
                    clear();
                };
                //button to activate line draw tool
                document.getElementById("Draw").onclick = function () {
                    console.log("Draw");
                    lineDrawTool(true);
                    //loop();
                };
                //button to deactivate drawing tool
                document.getElementById("Stop Draw").onclick = function () {
                    console.log("Stop Draw");
                    //noLoop();
                    lineDrawTool(false);
                };
                //button to clear lines drawn by line draw tool
                document.getElementById("Clear").onclick = function () {
                    console.log("Clear");
                    clear();
                };
            });
        };
        
    };
    
    
    this.destroy = function () {
        select("#chartdom").html("");
        select("#buttonDiv").html("");
        clear();
    };

    this.draw = function () {
        
    };
};