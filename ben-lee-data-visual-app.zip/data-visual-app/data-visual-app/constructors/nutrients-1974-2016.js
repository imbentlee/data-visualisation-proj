function NutrientsTimeSeries(){
    
    this.name = "Nutrients: 1974-2016";
    
    this.id = "nutrients-timeseries";
    
    this.title = "Nutrients: 1974-2016";
    
    // plot line title
    this.xAxisLabel = "year";
    this.yAxisLabel = "%";
    
    this.colors = [];
    
    var marginSize = 35;
    
    this.layout = {
        marginSize: marginSize,
        leftMargin: marginSize*2,
        rightMargin: width - marginSize,
        topMargin: marginSize,
        bottomMargin: height - marginSize*2,
        pad:5,
        
        plotWidth: function(){
            return this.rightMargin - this.leftMargin;
        },
        
        plotHeight: function(){
            return this.bottomMargin - this.topMargin;
        },
        
        //to enable/disable background grid
        grid: true,
        
        //number of axis tick labels
        numXTickLabels: 10,
        numYTickLabels: 8
    };
    
    this.preload = function() {
    var self = this;
    this.data = loadTable(
        './data/food/nutrients74-16.csv', 'csv', 'header',
        // Callback function to set the value
        // this.loaded to true.
        function(table) {
            self.loaded = true;
        });
    };
    
    this.setup = function(){
        textSize(16);
        this.startYear = Number(this.data.columns[1]);
        this.endYear = Number(this.data.columns[this.data.columns.length-1]);
        
        for(var i=0; i<this.data.getRowCount(); i++){
            this.colors.push(color(random(0, 255),
                             random(0, 255),
                             random(0, 255)));
        }
        
        //set the min/max %
        //this is hardcoded, can try make it dynamic in future
        //taken from data source
        this.minPercentage = 80;
        this.maxPercentage = 400;
    };
    
    this.destroy = function(){
        
    };
    
    this.draw = function(){
        if(!this.loaded){
            console.log("Data not yet loaded");
            return;
        }
        
        //draw graph title
        this.drawTitle();
        
        //draw y-axis labels
        drawYAxisTickLabels(this.minPercentage, this.maxPercentage,
                           this.layout, this.mapNutrientsToHeight.bind(this), 0);
        
        //draw x and y axis
        drawAxis(this.layout);
        
        //draw x and y axis labels
        drawAxisLabels(this.xAxisLabel, this.yAxisLabel, this.layout);
        
        //plot all nutrients between startYear and endYear using width of canvas - margins
        
        var numYears = this.endYear - this.startYear;
        
        //loop over all rows and draw a line from the previous value to the current value
        for(var i=0; i<this.data.getRowCount(); i++){
            
            var row = this.data.getRow(i);
            var previous = null;
            var title = row.getString(0); //name of the nutrients
            
            for(var j=1; j<numYears; j++){ //loop through  each year to get the value
                //create an object to store data for the current year
                var current = {
                    "year": this.startYear + j - 1,
                    "percentage": row.getNum(j)
                };
                
                if(previous!=null){
                    //draw line segment connecting previous year to year
                    stroke(this.colors[i]);
                    line(this.mapYearToWidth(previous.year),
                        this.mapNutrientsToHeight(previous.percentage), 
                        this.mapYearToWidth(current.year),
                        this.mapNutrientsToHeight(current.percentage));
                    
                    //the number of x-axis labels to skip so that only numXTickLabels are drawn
                    var xLabelSkip = ceil(numYears/this.layout.numXTickLabels);
                    
                    //draw the tick label marking the start of the previous year
                    if(i % xLabelSkip == 0){
                        
                        var currentTextSize = textSize();
                        textSize(9);
                        drawXAxisTickLabel(previous.year, this.layout,
                                          this.mapYearToWidth.bind(this));
                        textSize(currentTextSize);
                    }
                    
                }else{
                    noStroke();
                    
                    this.makeLegendItem(title, i, this.colors[i]);                          //this draws the legend at the corner
                }
                //assign current year to previous year so that it is available during the next iteration of this loop to give the start position of the next segment
                previous = current;
            }
        }
        this.drawBesideMouse();
        
    };
    
     this.drawTitle = function(){
         fill(0);
         noStroke();
         textAlign("center", "center");
         
         text(this.title,
             (this.layout.plotWidth()/2) + this.layout.leftMargin,
             this.layout.topMargin - (this.layout.marginSize/2));
     };
    
    this.mapYearToWidth = function(value){
        return map(value,
                  this.startYear, this.endYear,
                   this.layout.leftMargin, this.layout.rightMargin);
    };
    
    this.mapNutrientsToHeight = function(value){
        return map(value,
                  this.minPercentage, this.maxPercentage,
                  this.layout.bottomMargin, this.layout.topMargin);
    };
    
    this.drawBesideMouse = function(){
        var year = this.mapMouseXToYear(mouseX);
        var percent = this.mapMouseYToPercentage(mouseY);
        fill(0);
        noStroke();
        text("Percentage:" + percent, mouseX+15, mouseY);
        text("Year:" + year, mouseX+15, mouseY+20);
        
    };
    
    this.mapMouseXToYear = function(value){
        return int(map(value,
                      this.layout.leftMargin, this.layout.rightMargin,
                      this.startYear, this.endYear));
    };
    
    this.mapMouseYToPercentage = function(value){
        return int(map(value,
                      this.layout.bottomMargin, this.layout.topMargin,
                      this.minPercentage, this.maxPercentage));
    };
    
    this.makeLegendItem = function(label, i, color){
        var boxWidth = 50;
        var boxHeight = 10;
        var x = 800;
        var y = 50 + (boxHeight+2)*i;
        
        noStroke();
        fill(color);
        rect(x, y, boxWidth, boxHeight);
        
        fill("black");
        noStroke();
        textAlign("left", "center");
        textSize(12);
        text(label, x+boxWidth+10, y+boxHeight/2);
    };
    
}