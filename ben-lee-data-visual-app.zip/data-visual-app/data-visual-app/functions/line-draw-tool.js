var pointInPixelX;
var pointInPixelY;

function lineDrawTool(Boolean){
    
    var isTrue = Boolean;
    
    var startMouseX = -1;
	var startMouseY = -1;
	var drawing = false;
    
    if(isTrue == true){
        this.draw = function(){
	    
            //only draw when mouse is clicked
            if(mouseIsPressed){

                //start new line
                if(startMouseX == -1){

                    startMouseX = pointInPixelX;
                    startMouseY = pointInPixelY;

                    drawing = true;
                    loadPixels();
                }

                else{
                    //update the screen with the saved pixels to hide any previous
                    updatePixels();
                    //line between mouse pressed and released
                    //draw the line
                    line(startMouseX, startMouseY, pointInPixelX, pointInPixelY);
                }
            }else if(drawing){
                //save the pixels with the most recent line and reset the
                //drawing bool and start locations
                loadPixels();
                drawing = false;
                startMouseX = -1;
                startMouseY = -1;
            }
	   }
    }else if(isTrue == false){
        this.draw = null;
    }	
};