//function to create candlestick chart using echarts library
function createCandlesticks(date, temp) {

    var myChart = document.getElementById("chartdom")
    myChart.removeAttribute("_echarts_instance_");
    var option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross'
            }
        },
        xAxis: {
            data: date,
            show: true
        },
        yAxis: {
            show: true
        },
        dataZoom: [{}, {
            type: 'slider'
        }],
        series: [{
            type: 'candlestick',
            data: temp,
            itemStyle: {
                color: 'green',
                color0: 'red',
                borderColor: 'green',
                borderColor0: 'red'
            }
        }]
    };
    var charts_ = echarts.init(document.getElementById('chartdom'));
    charts_.setOption(option);
    
    //function gets cursor position on echarts canvas 
    charts_.getZr().on('mousemove', function (params) {
       
        // still use mouseX & mouseY as cursor position
        pointInPixelX = mouseX;
        pointInPixelY = mouseY;

    });
};

//function to split arrays into chunks
function splitArray(arr, size) {
  var chunks = [], i = 0, n = arr.length;
  while (i < n) {
    chunks.push(arr.slice(i, i += size));
  }
  return chunks;
};

//function to determine start date of each time period
function startDates(arr){
    var startDate = [];
    
    for(var i=0; i<arr.length; i++){
        startDate.push(arr[i][0]);
    }
    return startDate;
};

//function to determine end date of each time period
function endDates(arr){
    var endDate = [];
    
    for(var i=0; i<arr.length; i++){
        endDate.push(arr[i][arr[i].length-1]);
    }
    return endDate;
};

//function to determine date range of each time period
function dateRange(start, end){
    var dateRange = [];
    
    for(var i=0; i<start.length; i++){
        dateRange.push(start[i] +'-'+ end[i]);
    }
    return dateRange;
};

//function to find lowest value in given time preiods
function findLow(arr){
    var lowestValue = [];
    for(var i=0; i<arr.length; i++){
        lowestValue.push(min(arr[i]));
    }
    return lowestValue;
};

//function to find highest value in given time preiods
function findHigh(arr){
    var highestValue = [];
    for(var i=0; i<arr.length; i++){
        highestValue.push(max(arr[i]));
    }
    return highestValue;
};